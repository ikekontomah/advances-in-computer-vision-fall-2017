% Hint: For debugging functions in MATLAB, it could be useful
% to use the command 'dbstop if error'. This will allow you 
% to use the terminal within the scope of a function when an 
% error occurs. You can remove this option by typing 'dbclear
% if error'. To continue from a debug stop, you can type 
% 'dbcont', or 'dbquit' to return to regular terminal.

% read in the images
im1 = imread('seoul/img1.jpg');
im2 = imread('seoul/img2.jpg');

% make panorama
imPano = Photomerge(im1, im2);

% show original images + result
figure(1); clf;
subplot(2,2,1); imshow(im1);
subplot(2,2,2); imshow(im2);
subplot(2,2,3:4); imshow(imPano);