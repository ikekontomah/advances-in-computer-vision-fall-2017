function [im] = MakePanorama(im1, im2, T)

%% FILL IN YOUR CODE BELOW

% Hint: you may use maketform to make a transformation from your T matrix.
%  You can apply this transform using imtransform.