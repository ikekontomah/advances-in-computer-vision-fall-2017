function [im] = Photomerge(im1, im2)

% Compute and match SIFT descriptors


% Call TransformRANSAC to obtain the homography matrix


% Call MakePanorama to obtain the final panorama

