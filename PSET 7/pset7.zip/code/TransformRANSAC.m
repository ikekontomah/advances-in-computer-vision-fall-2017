function [T] = TransformRANSAC(x1, x2)

%% FILL IN YOUR CODE BELOW (SKELETON CODE PROVIDED)

% Initialize your parameters, such as number of iterations,
% matching threshold, etc

numIter = 200;
%% ADD MORE PARAMETERS HERE

% Run RANSAC for required number of iterations
% RANSAC PSEUDOCODE PROVIDED BELOW - FILL IN DETAILS

for i=1:numIter
  % Select a subset of points
  
  
  % Using the selected points, estimate homography
  
  
  % Score homography by counting number of points
  % lying within the threshold
  
  
  % If this is the highest-scoring homography found 
  % so far, store it (and the matching points), else ignore
  
  
end

% Recompute the homography using ALL of the best set 
% of points found above