function v = foo2(v)

v(1) = 17;
