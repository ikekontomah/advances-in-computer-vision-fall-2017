function v = foo1(v)

tmp = 5;
v(1) = 17;
