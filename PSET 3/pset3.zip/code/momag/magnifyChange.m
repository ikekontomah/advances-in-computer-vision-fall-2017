% 6.869 Advances in Computer Vision
% Problem Set 3

function magnified = magnifyChange(im1, im2, magnificationFactor)
    % find phase shift in frequency domain
    im1Dft = fft2(im1);
    im2Dft = fft2(im2);
    phaseShift = % TODO
    
    % magnify the phase change in frequency domain
    magnifiedDft = % TODO

    % what does the magnified phase change cause in image space?
    magnified = ifft2(magnifiedDft);
end