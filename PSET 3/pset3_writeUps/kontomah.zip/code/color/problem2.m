%Problem 2 
%a.
cie_match_matrix=load("CIEMatch.mat") ;
cie_rgb_matrix=load("CIE2RGB.mat");
lms_response_matrix=load("LMSResponse.mat");
result= cie_rgb_matrix.T*cie_match_matrix.CIEMatch  ;
result2=cie_match_matrix.CIEMatch ;
result3=lms_response_matrix.LMSResponse;
colors_to_use=['r','g','b'] ;
%i.
figure 
title("Color Matching Functions") ;
hold on 
x_val=linspace(360,730,(730-360)/5+1) ;
for ele =1:3
    plot((360:5:730),result(ele,:),colors_to_use(ele)) 
    %Title("Color Matching Functions") 
end

%ii.
I=eye(3) ;
primary_light_spectra=result\I ;
primary_light_spectra=primary_light_spectra' ;
figure 
title("Primary light spectra") ;
hold on 
for ele =1:3
    plot((360:5:730),primary_light_spectra(ele,:),colors_to_use(ele)) 
    %Title("Color Matching Functions") 
end

%iii.
figure
title("CIE Color Matching Functions") ;
hold on 
for ele =1:3
    
    plot(x_val,result2(ele,:),colors_to_use(ele)) 
    %Title("Color Matching Functions") 
end 

%iv.
figure
I=eye(3) ;
primary_light_spectra_CIE=result2\I ;
primary_light_spectra_CIE=primary_light_spectra_CIE' ;
title("Primary Light Spectra For CIE Color Space") ;
hold on 
for ele =1:3
    plot(x_val,primary_light_spectra_CIE(ele,:),colors_to_use(ele)) 
    %Title("Color Matching Functions") 
end 

%b.
figure
I=eye(3) ;
lms_response=result3\I ;
lms_response=lms_response' ;
title("Primary Light Spectra For LMS Response") ;
hold on 
for ele =1:3
    plot(x_val,lms_response(ele,:),colors_to_use(ele)) 
    %Title("Color Matching Functions") 
end 
